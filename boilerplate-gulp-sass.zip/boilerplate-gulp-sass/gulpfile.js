var gulp = require('gulp');
var browserSync = require('browser-sync').create();

var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var rename = require('gulp-rename');

var sass = require('gulp-sass');
var minifycss = require('gulp-minify-css');

gulp.task('default', ['_browsersync', '_copyangularlib', '_copyangularmateriallib', '_copyangularmaterialcsslib', '_concatand_uglify', '_sass'], function(){

});

gulp.task('_browsersync', function(){
  browserSync.init({
    server: {
      baseDir: 'www'
    },
  })
});

gulp.task('_copyangularlib', function(){
  return gulp.src('node_modules/angular/angular.min.js')
  .pipe(gulp.dest('www/lib'));
});

gulp.task('_copyangularmateriallib', function(){
  return gulp.src('node_modules/angular-material/angular-material.min.js')
  .pipe(gulp.dest('www/lib'));
});

gulp.task('_copyangularmaterialcsslib', function(){
  return gulp.src('node_modules/angular-material/angular-material.min.css')
  .pipe(gulp.dest('www/lib'));
});

gulp.task('_concatand_uglify', function(){
  return gulp.src('src/app/**/*.js')
  .pipe(concat('main.js'))
  .pipe(gulp.dest('www/js'))
  .pipe(uglify())
  .pipe(rename('main.min.js'))
  .pipe(gulp.dest('www/js'));
});

gulp.task('_sass', function(){
  return gulp.src('src/sass/*.scss')
  .pipe(sass())
  .pipe(concat('main.css'))
  .pipe(gulp.dest('www/css'))
  .pipe(minifycss())
  .pipe(rename('main.min.css'))
  .pipe(gulp.dest('www/css'));
});

gulp.task('_watchall', function(){
  gulp.watch('src/app/**/*.js', ['_concatand_uglify']);
  gulp.watch('src/sass/*.scss', ['_sass']);
  gulp.watch('www/*.html', browserSync.reload);
});

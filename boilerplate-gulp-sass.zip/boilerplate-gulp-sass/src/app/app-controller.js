var app = angular.module('mainApp', ['ngMaterial']);

app.controller('mainCtrl', ['$scope', function($scope){
  
}]);
